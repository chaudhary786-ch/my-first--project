class student:
    def __init__(self, name,rol_number):
        self.name = name
        self.rol_number = rol_number
    def greet(self):
        print("Hello",self.name,"your roll number is",self.rol_number)
s1=student("Ali",101)
s2=student("Ahmad",102)
s3=student("Aqib",103)
s4=student("Ahsan",104)

s1.greet() 
s2.greet()
s3.greet()
s4.greet()